var adwhirl = require('videohya.adwhirlvpon');
Ti.API.info("module is => "+adwhirl);

var win = Ti.UI.createWindow({
	backgroundColor:'#fff'
});

var adView = adwhirl.createAdView({
	height:48,
	width:320,
	top:50,
	backgroundColor:'#000',
	applicationKey:'cb96df0e99fa4c54a0b73d822cfc35d6'
});
win.add(adView);

win.open();